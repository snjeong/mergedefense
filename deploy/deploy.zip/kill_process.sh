#!/usr/bin
sudo pkill -f 'java -jar'